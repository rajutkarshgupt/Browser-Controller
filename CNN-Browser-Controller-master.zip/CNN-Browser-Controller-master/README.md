# CNN-Browser-Controller
Controlling browser using gestures
